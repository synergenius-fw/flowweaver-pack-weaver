import * as fs from 'node:fs';
import * as path from 'node:path';
import * as os from 'node:os';
import type { WeaverContext, StepLogEntry } from '../bot/types.js';
import { callAI, parseJsonResponse, normalizePlan } from '../bot/ai-client.js';
import { executeStep } from '../bot/step-executor.js';
import { validateFiles } from '../bot/file-validator.js';
import { auditEmit } from '../bot/audit-logger.js';

/**
 * Execute-validate-fix retry loop. Runs the plan, validates results,
 * and if validation fails, asks the AI for fixes. Up to 3 attempts.
 *
 * @flowWeaver nodeType
 * @label Execute & Validate
 * @input ctx [order:0] - Weaver context (JSON)
 * @output ctx [order:0] - Weaver context with results (JSON)
 * @output onSuccess [order:-2] - On Success
 * @output onFailure [order:-1] [hidden] - On Failure
 */
export async function weaverExecValidateRetry(
  execute: boolean,
  ctx: string,
): Promise<{
  onSuccess: boolean; onFailure: boolean;
  ctx: string;
}> {
  const context = JSON.parse(ctx) as WeaverContext;
  const { env } = context;

  if (!execute) {
    context.resultJson = JSON.stringify({ success: true, stepsCompleted: 0, stepsTotal: 0 });
    context.validationResultJson = '[]';
    context.filesModified = '[]';
    context.allValid = true;
    return { onSuccess: true, onFailure: false, ctx: JSON.stringify(context) };
  }

  const { providerInfo: pInfo, projectDir } = env;
  const maxAttempts = 3;
  const taskDeadline = Date.now() + 180_000; // 3 minute max per task
  let currentPlan = JSON.parse(context.planJson!);
  let allFilesModified: string[] = [];
  let allStepLog: StepLogEntry[] = [];
  let lastExecResult: Record<string, unknown> = {};
  let lastValidation: Array<{ file: string; valid: boolean; errors: string[] }> = [];
  let allValid = false;
  let prevErrorCount = Infinity;

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    // Task timeout — stop if we've exceeded the deadline
    if (Date.now() > taskDeadline) {
      console.error('\x1b[33m→ Task timeout (3 min), moving on\x1b[0m');
      break;
    }

    console.log(`\x1b[36m→ Attempt ${attempt}/${maxAttempts}\x1b[0m`);
    auditEmit('step-start', { attempt, stepCount: currentPlan.steps?.length });

    const execResult = await executePlanSteps(currentPlan, projectDir);
    lastExecResult = execResult;
    allFilesModified = [...new Set([...allFilesModified, ...execResult.filesModified])];
    allStepLog.push(...execResult.stepLog);
    auditEmit('step-complete', { attempt, filesModified: execResult.filesModified, errors: execResult.errors });

    const validation = await validateFiles(execResult.filesModified, projectDir);
    lastValidation = validation;
    allValid = validation.every(v => v.valid);
    const errorCount = validation.filter(v => !v.valid).length;
    auditEmit('validation-run', { attempt, allValid, errorCount });

    // Stop retrying if errors didn't decrease — AI is stuck
    if (attempt > 1 && errorCount >= prevErrorCount) {
      console.error(`\x1b[33m→ Errors not decreasing (${errorCount} >= ${prevErrorCount}), stopping retry\x1b[0m`);
      break;
    }
    prevErrorCount = errorCount;

    // Collect design warnings from valid files
    const designWarnings = validation
      .filter(v => v.valid && v.warnings.length > 0)
      .map(v => `${v.file}:\n${v.warnings.map(w => `  - ${w}`).join('\n')}`)
      .join('\n');

    if (allValid && !designWarnings) {
      console.log('\x1b[32m→ All files valid, no design issues\x1b[0m');
      break;
    }

    if (allValid && designWarnings) {
      console.log('\x1b[32m→ All files valid\x1b[0m');
      console.log(`\x1b[33m→ Design warnings:\n${designWarnings}\x1b[0m`);
      // Design warnings don't block, but include them for the AI on the next attempt
      if (attempt < maxAttempts) {
        // Only retry for design issues if there are warning/error severity checks
        const hasActionable = validation.some(v =>
          v.designReport?.checks.some(c => c.severity === 'warning' || c.severity === 'error'),
        );
        if (!hasActionable) break;
      } else {
        break;
      }
    }

    if (attempt < maxAttempts) {
      console.log(`\x1b[33m→ Validation errors found, requesting fix plan...\x1b[0m`);
      const validationErrors = validation.filter(v => !v.valid).map(v => `${v.file}: ${v.errors.join(', ')}`).join('\n');
      const errors = [validationErrors, designWarnings].filter(Boolean).join('\n\nDesign issues:\n');

      try {
        auditEmit('fix-attempt', { attempt });

        let systemPrompt: string;
        try {
          const mod = await import('../bot/system-prompt.js');
          systemPrompt = await mod.buildSystemPrompt();
        } catch (err) {
          if (process.env.WEAVER_VERBOSE) console.error('[exec-validate-retry] system prompt build failed:', err);
          systemPrompt = 'You are Weaver. Return ONLY valid JSON.';
        }

        // Include step outputs so the AI has context from discovery steps
        const outputContext = Object.entries(execResult.stepOutputs)
          .map(([id, out]) => `--- Output of ${id} ---\n${out}`)
          .join('\n\n');

        const fixPrompt = `The following validation errors occurred:\n${errors}\n\n${outputContext ? `Discovery step outputs:\n${outputContext}\n\n` : ''}Provide a CONCRETE fix plan. Every patch-file step MUST include "file" (absolute path from the outputs above) and "patches" array with exact "find"/"replace" strings. Do NOT use placeholders.`;

        const text = await callAI(pInfo, systemPrompt, fixPrompt, 8192);

        const parsed = parseJsonResponse(text);
        currentPlan = normalizePlan(parsed);
        console.log(`\x1b[36m→ Fix plan: ${currentPlan.summary} (${currentPlan.steps.length} steps)\x1b[0m`);
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : String(err);
        console.error(`\x1b[31m→ Fix planning failed: ${msg}\x1b[0m`);
        break;
      }
    }
  }

  context.resultJson = JSON.stringify(lastExecResult);
  context.validationResultJson = JSON.stringify(lastValidation);
  context.filesModified = JSON.stringify(allFilesModified);
  context.stepLogJson = JSON.stringify(allStepLog);
  context.allValid = allValid;

  return { onSuccess: allValid, onFailure: !allValid, ctx: JSON.stringify(context) };
}

async function executePlanSteps(
  plan: { steps: Array<{ id: string; operation: string; description: string; args: Record<string, unknown> }> },
  projectDir: string,
): Promise<{ success: boolean; filesModified: string[]; errors: string[]; stepsCompleted: number; stepsTotal: number; stepLog: StepLogEntry[]; stepOutputs: Record<string, string> }> {
  const filesModified: string[] = [];
  const errors: string[] = [];
  const stepLog: StepLogEntry[] = [];
  const stepOutputs: Record<string, string> = {};
  let completed = 0;
  const steps = plan.steps ?? [];

  for (const step of steps) {
    const steering = checkSteeringSignal();
    if (steering === 'cancel') {
      errors.push(`Cancelled at step ${step.id}`);
      stepLog.push({ step: step.id, status: 'error', detail: 'Cancelled by steering signal' });
      break;
    }

    try {
      const result = await executeStep(step, projectDir);
      if (result.blocked) {
        console.error(`\x1b[33m  ⚠ ${step.id}: ${result.blockReason}\x1b[0m`);
        stepLog.push({ step: step.id, status: 'blocked', detail: result.blockReason });
        continue;
      }
      if (result.file) filesModified.push(result.file);
      if (result.files) filesModified.push(...result.files);
      // Capture step output for feeding into fix prompts
      if (result.output) {
        stepOutputs[step.id] = result.output.slice(0, 4000); // cap at 4k to fit in prompt
      }
      completed++;
      console.log(`\x1b[32m  + ${step.id}: ${step.description}\x1b[0m`);
      stepLog.push({ step: step.id, status: 'ok', detail: step.description });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      errors.push(`${step.id}: ${msg}`);
      console.error(`\x1b[31m  x ${step.id}: ${msg}\x1b[0m`);
      stepLog.push({ step: step.id, status: 'error', detail: msg });
    }
  }

  return { success: errors.length === 0, filesModified: [...new Set(filesModified)], errors, stepsCompleted: completed, stepsTotal: steps.length, stepLog, stepOutputs };
}

function checkSteeringSignal(): 'cancel' | null {
  try {
    const controlPath = path.join(os.homedir(), '.weaver', 'control.json');
    if (!fs.existsSync(controlPath)) return null;
    const raw = fs.readFileSync(controlPath, 'utf-8');
    fs.unlinkSync(controlPath);
    const cmd = JSON.parse(raw) as { command: string };
    if (cmd.command === 'cancel') return 'cancel';
    return null;
  } catch {
    return null;
  }
}
